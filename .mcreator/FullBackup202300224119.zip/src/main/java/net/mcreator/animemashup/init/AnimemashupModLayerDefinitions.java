package net.mcreator.animemashup.init;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.ModelLayerLocation;

public class AnimemashupModLayerDefinitions {
	public static final ModelLayerLocation HEADBAND = new ModelLayerLocation(new ResourceLocation("animemashup", "headband"), "headband");
	public static final ModelLayerLocation PURPLE_KUSANAGI_BAUBLE = new ModelLayerLocation(new ResourceLocation("animemashup", "purple_kusanagi_bauble"), "purple_kusanagi_bauble");
}
